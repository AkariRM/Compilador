package lalo;

public class RepasoMain {

	public static void main(String[] args) {
		Repaso obr  = new Repaso();
		obr.Leer();
		obr.Mostrar(obr.Operacion());
	}
}
