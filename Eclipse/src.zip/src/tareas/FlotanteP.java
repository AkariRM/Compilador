package tareas;

public class FlotanteP {

	public static void main(String[] args) {
		Flotante obf = new Flotante();
		
		obf.verificarNumero();
	}
}
